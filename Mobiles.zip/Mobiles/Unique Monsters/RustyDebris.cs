using System;

namespace Server.Items
{
	public class RustyDebris : Item
	{
		[Constructable]
		public RustyDebris() : base( 0xC2D )
		{
			Weight = 3.0;
            Name = "rusty debris";
            Hue = 2964;
		}

		public RustyDebris( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}
